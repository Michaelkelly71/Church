<?php 
 $db= mysqli_connect("localhost","root","","ch");
 session_start();



 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title>Members</title>
 </head>
 <body>
 <div class="container">
 	<table>
 		<th>First Name</th>
 		<th>Last Names</th>
 		<th>MI</th>
 		<th>Address</th>
 		<th>Date of Birth </th>
 		<th>Gender</th>
 	</table>

 </div>


 </body>
 </html>